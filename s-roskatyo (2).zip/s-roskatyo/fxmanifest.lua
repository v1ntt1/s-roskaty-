fx_version 'adamant'
game {'gta5'}

description 'tässä teille roskatyö jos haluutte :)'
author 'Silu321'
version '1.0.1'


lua54 'yes'

client_scripts {
        "clientti/*.lua"
}

server_scripts {
        "serveri/*.lua"
}

shared_scripts {
  'sharedi.lua',
  '@ox_lib/init.lua'
}